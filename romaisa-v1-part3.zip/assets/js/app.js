let cart=JSON.parse(localStorage.getItem('cart')||'[]');
function addItem(name){cart.push(name);localStorage.setItem('cart',JSON.stringify(cart));alert(name+' ajouté au panier');}
function renderCart(){const ul=document.getElementById('cart');if(!ul)return;ul.innerHTML='';cart.forEach((i,n)=>{ul.innerHTML+=`<li>${i} <button onclick="removeItem(${n})">X</button></li>`});}
function removeItem(i){cart.splice(i,1);localStorage.setItem('cart',JSON.stringify(cart));renderCart();}
window.onload=renderCart;